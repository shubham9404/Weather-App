//
//  ViewController.swift
//  MyWeatherApp
//
//  Created by Shubham Shinde on 05/02/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController, MKMapViewDelegate,UITextFieldDelegate{
    @IBOutlet weak var viewImage: UIImageView!
    
    var imageArray = ["scattered.png", "smoke.png", "clearsky.png", "haze.png", "cloud.png", "light rain", "overcastcloud.png", "rain.png"]
    @IBOutlet weak var enterCity: UITextField!
    
    @IBOutlet weak var watherLable: UILabel!
    @IBOutlet weak var weatherDisplay: UILabel!
    
    @IBOutlet weak var tempratureLable: UILabel!
    @IBOutlet weak var tempratureDisplay: UILabel!
    
    @IBOutlet weak var pressureLable: UILabel!
    @IBOutlet weak var pressureDisplay: UILabel!
    
    @IBOutlet weak var humidityLable: UILabel!
    @IBOutlet weak var humidityDisplay: UILabel!
    
    var lat = 0.0
    var log = 0.0
    
    enum JsonError:String,Error {
        case responseError = "Response Error"
        case dataError = "Data Error"
        case configurationError = "ConfigurationError"
    }
    
    func parser()
    {
        let urlString = "https://api.openweathermap.org/data/2.5/weather?lat=\(lat)&lon=\(log)&appid=c1a5cafcc7ba92a8e8f44983a4a84200"
        let url:URL = URL(string: urlString)!
        let sessionConfiguration = URLSessionConfiguration.default
        let session = URLSession( configuration:sessionConfiguration)
        let dataTask = session.dataTask(with: url) { (data, response, error) in
            do
            {
                guard let response   =  response else
                {
                    throw JsonError.responseError
                }
                guard let data = data else
                {
                    throw JsonError.dataError
                }
                guard let dic = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String:Any] else
                {
                    throw JsonError.configurationError
                }
                
                let weatherArray = dic["weather"] as! [[String:Any]]
                let weatherDic = weatherArray.first!
                    let description = weatherDic["description"] as! String
                    print(description)
                let mainDic = dic["main"] as! [String:Any]
                let temp = mainDic["temp"] as! Double
                let tempStr = String(temp)
                print(tempStr)
                let  humidity = mainDic["humidity"] as! Double
                let humidityStr = String(humidity)
                    print(humidityStr)
                let pressure = mainDic["pressure"] as! Double
                let pressureStr = String(pressure)
                print(pressureStr)
                
                DispatchQueue.main.async
                {
                    self.weatherDisplay.text = description
                    self.tempratureDisplay.text = tempStr
                    self.humidityDisplay.text = humidityStr
                    self.pressureDisplay.text = pressureStr
                    if self.weatherDisplay.text! == "scattered clouds"{
                        //self.imageBorder()
                        self.viewImage.image = UIImage(named: "scattered.png")
                    }
                    else if self.weatherDisplay.text! == "clear sky"{
                        //self.imageBorder()
                        self.viewImage.image = UIImage(named: "clearsky.png")
                    }
                    else if self.weatherDisplay.text! == "smoke"{
                        //self.imageBorder()
                        self.viewImage.image = UIImage(named: "smoke.png")
                    }
                    
                    else if self.weatherDisplay.text! == "haze"{
                        self.viewImage.image = UIImage(named: "haze.png")
                        //self.imageBorder()
                    }
                    else if self.weatherDisplay.text! == "few clouds"{
                        self.viewImage.image = UIImage(named: "cloud.png")
                        //self.imageBorder()
                    }
                    else if self.weatherDisplay.text! == "light rain"{
                        self.viewImage.image = UIImage(named: "lightrain.png")
                        //self.imageBorder()
                    }
                    else if self.weatherDisplay.text! == "overcast clouds"{
                        self.viewImage.image = UIImage(named: "overcastcloud.png")
                        //self.imageBorder()
                    }
                    else if self.weatherDisplay.text! == "Rainy"{
                        self.viewImage.image = UIImage(named: "rain.png")
                        //self.imageBorder()
                    }
                }
            }
        catch let err
            {
                print(err)
            }
        }
        dataTask.resume()
    }
    
//    private func imageBorder() {
//        viewImage.layer.borderWidth = 05.0
//        viewImage.layer.cornerRadius = 10.0
//        let myColor : UIColor = UIColor.black
//        viewImage.layer.borderColor = myColor.cgColor
//    }
    
    @IBAction func goAction(_ sender: UIButton) {
        let geo = CLGeocoder()
        geo.geocodeAddressString(enterCity.text!) { (placemarks, error) in
            let coordinate = placemarks?.first?.location?.coordinate
            self.lat = (coordinate?.latitude)!
            self.log = (coordinate?.longitude)!
            self.parser()
    }
    }
    
//    @IBAction func textFieldShouldReturn(_ sender: Any) {
//        let geo = CLGeocoder()
//        geo.geocodeAddressString(enterCity.text!) { (placemarks, error) in
//            let coordinate = placemarks?.first!.location?.coordinate
//            self.lat = (coordinate?.latitude)!
//            self.log = (coordinate?.longitude)!
//            //let span = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
//           // let region = MKCoordinateRegion(center:coordinate!, span: span)
//        }
//        parser()
//    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        enterCity.delegate = self
        // Do any additional setup after loading the view.
    }


}

